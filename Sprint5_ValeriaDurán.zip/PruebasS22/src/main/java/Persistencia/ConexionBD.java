
package Persistencia;

/**
 *
 * @author valeriaduran
 */

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ConexionBD {
    private String  DB_driver = "";  
    private String  url = "";  
    private String  db = "";  
    private String  host = "";  
    private String  username = ""; 
    private String  password = "";  
    public Connection conexion = null;  
    private ResultSet rs = null;
    private Statement stmt = null;
    
    public ConexionBD () {
    host ="localhost: 3306";
    db ="pruebasS22";
    url ="jdbc:mysql://" + host + "/" + db;
    username = "root";
    password = "Ad0edd84ac99b";
    DB_driver = "com.mysql.cj.jdbc.Driver";

    try {
    //Asignación DRIVER
    Class.forName(DB_driver);
    } catch (ClassNotFoundException ex) {
    Logger.getLogger (ConexionBD.class.getName()).log(Level.SEVERE,null, ex);
    }

try {
        conexion = DriverManager.getConnection(url, username, password);
        System.out.println("Conexión exitosa");
    } catch (SQLException ex) {
        Logger.getLogger (ConexionBD.class.getName()).log(Level.SEVERE,null, ex);
        
    }
}

public Connection getConnection (){
    return conexion;
}
    
public void closeConnection(){
    if(conexion != null) {
    try {
        conexion.close();
    } catch (SQLException ex) {
        Logger.getLogger (ConexionBD.class.getName()).log(Level.SEVERE,null, ex);
    }
  }
}

public ResultSet consultarBD (String sentencia) {
    try {
        stmt = conexion.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        rs = stmt.executeQuery(sentencia);
    } catch (SQLException | RuntimeException sqlex){
    Logger.getLogger (ConexionBD.class.getName()).log(Level.SEVERE,null, sqlex);
}
    return rs;
        
}

public boolean insertarBD (String sentencia) {
try {
stmt = conexion.createStatement();
stmt.execute(sentencia);
return true;
}catch (SQLException | RuntimeException sqlex) {
Logger.getLogger (ConexionBD.class.getName()).log(Level.SEVERE,null, sqlex);
return false;
}
}

public boolean borrarBD (String sentencia) {
try{
stmt = conexion.createStatement();
stmt.execute(sentencia);
return true;
} catch (SQLException | RuntimeException sqlex) {
System.out.println("Error borrar BD");
Logger.getLogger (ConexionBD.class.getName()).log(Level.SEVERE,null, sqlex);  
return false;
}
}

public boolean actualizarBD (String sentencia) {
try{
stmt = conexion.createStatement();
stmt.execute(sentencia);
return true;
} catch (SQLException | RuntimeException sqlex) {
System.out.println("Error actualizar BD");
Logger.getLogger (ConexionBD.class.getName()).log(Level.SEVERE,null, sqlex);  
return false;
}
}

public boolean setAutoCommitBD (boolean commit) {
try {
conexion.setAutoCommit(commit);
return true;
} catch (SQLException ex) {
System.out.println("Error en setAutoCommit");
return false;
}
}

public boolean commitBD () {
try {
conexion.commit();
return true;
} catch (SQLException ex) {
System.out.println("Error en CommitBD");
return false;
}
}

public boolean rollbackBD () {
try {
conexion.rollback();
return true;
} catch (SQLException ex) {
System.out.println("Error en Crollback");
return false;
}
}
}
//////}




