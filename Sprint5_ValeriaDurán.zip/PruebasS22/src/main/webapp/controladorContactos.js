
var app = angular.module('prueba', []);
app.controller('controladorContactos', function ($scope, $http) {

    $scope.guardarContacto = function () {
        if ($scope.Apellido === undefined || $scope.Correo === undefined || $scope.Usuario === undefined) {
            alert('Todos los campos son obligatorios');
        } else {
            let contacto = {
                proceso: "guardarContacto",
                Nombre: $scope.nombre,
                Apellido: $scope.Apellido,
                Correo: $scope.Correo,
                Ciudad: $scope.Ciudad,
                Usuario: $scope.Usuario,
                Contraseña: $scope.Contraseña
            };
            console.log(contacto);
            $http({
                method: 'POST',
                url: 'peticionesContacto.jsp',
                params: contacto
            }).then(function (respuesta) {
                console.log(respuesta);
                alert('Guardado exitoso');
            });
        }
    }

    $scope.listarContacto = function () {
        console.log('Entra listar contactos');
        $scope.mostrarListaContactos = true;
        let params = {
            proceso: 'listarContactos'
        }
        $http({
            method: 'GET',
            url: 'peticionesContacto.jsp',
            params: params
        }).then(function (respuesta) {
            $scope.contactos = respuesta.data.contactos;
            console.log($scope.contactos);
        })
    };

    $scope.eliminarContacto = function (Nombre) {
        let params = {
            proceso: 'eliminarContacto',
            Nombre: Nombre
        };
        $http({
            method: 'GET',
            url: 'peticionesContacto.jsp',
            params: params
        }).then(function (respuesta) {
            console.log(respuesta);
            alert('Se eliminó exitosamente');
            $scope.listarContacto();
        });
    };

    $scope.actualizarContacto = function () {
        let contacto = {
            proceso: "actualizarContacto",
            Nombre: $scope.nombre,
            Apellido: $scope.Apellido,
            Correo: $scope.Correo,
            Ciudad: $scope.Ciudad,
            Usuario: $scope.Usuario,
            Contraseña: $scope.Contraseña
        };
        $http ({
            method: 'POST',
            url: 'peticionesContacto.jsp',
            params: contacto
        }).then (function(respuesta){           
            if (respuesta.data.actualizarContacto){
             alert('Se actualizó exitosamente');   
            } else {
             alert('No se pudo actualizar'); 
            }
        });
    };

    $scope.mostrarFormularioMetodo = function () {
        $scope.mostrarListaContactos = false;
    };
    
    $scope.mostrarFormularioActualizar = function (contacto){
        $scope.mostrarListaContactos =false;
        $scope.actualizar = true;
        $scope.Nombre = contacto.Nombre;
        $scope.Apellido= contacto.Apellido;
        $scope.Correo= contacto.Correo;
        $scope.Ciudad= contacto.Ciudad;
        $scope.Usuario= contacto.Usuario;
        $scope.Contraseña= contacto.Contraseña;
    };
});


            