/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import Persistencia.ConexionBD;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriaduran
 */
public class Contacto {

    private String Nombre;
    private String Apellido;
    private String Correo;
    private String Ciudad;
    private String Usuario;
    private String Contraseña;

    public Contacto() {

    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public String getCiudad() {
        return Ciudad;
    }

    public void setCiudad(String Ciudad) {
        this.Ciudad = Ciudad;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

    public boolean guardarContacto() {

        ConexionBD conexion = new ConexionBD();
        String sentencia = "INSERT INTO nuevosContactos (Nombre, Apellido, Correo, Ciudad, Usuario, Contraseña)"
                + "VALUES ('" + this.Nombre + "','" + this.Apellido + "','" + this.Correo + "','"
                + this.Ciudad + "','" + this.Usuario + "','" + this.Contraseña + "');";

        if (conexion.setAutoCommitBD(false)) {
            if (conexion.insertarBD(sentencia)) {
                conexion.commitBD();
                conexion.closeConnection();
                return true;
            } else {
                conexion.rollbackBD();
                conexion.closeConnection();
                return false;
            }
        } else {
            conexion.closeConnection();
            return false;
        }
    }

    public boolean eliminarContacto (String nombre) {
        ConexionBD conexion = new ConexionBD();
        String sentencia = "DELETE FROM contactos WHERE nombre = '" + nombre + "'";
        if (conexion.setAutoCommitBD(false)) {
            if (conexion.borrarBD(sentencia)) {
                conexion.commitBD();
                conexion.closeConnection();
                return true;
            } else {
                conexion.rollbackBD();
                conexion.closeConnection();
                return false;

            }

        } else {
            conexion.closeConnection();
            return false;
        }
    }

    public boolean actualizarContacto() {
        ConexionBD conexion = new ConexionBD();
        String sentencia = "UPDATE contactos SET Nombre = '" + this.Nombre + "', Apellido = '"
                + this.Apellido + "', Correo = '" + this.Correo + "', Ciudad = '" + this.Ciudad + "', Usuario = '"
                + this.Usuario + "', Contraseña = '" + this.Contraseña + " 'WHERE Nombre =" + this.Nombre + ";";

        if (conexion.setAutoCommitBD(false)) {
            if (conexion.actualizarBD(sentencia)) {
                conexion.commitBD();
                conexion.closeConnection();
                return true;
            } else {
                conexion.rollbackBD();
                conexion.closeConnection();
                return false;
            }
        }
        return false;
    }

    public List<Contacto> listarContactos() throws SQLException {
        ConexionBD conexion = new ConexionBD();
        String sentencia = "SELECT * FROM nuevosContactos";
        List<Contacto> listaContactos = new ArrayList<>();
        ResultSet datos = conexion.consultarBD(sentencia);
        Contacto contacto;
        while (datos.next()) {
            contacto = new Contacto();
            contacto.setNombre(datos.getString("Nombre"));
            contacto.setApellido(datos.getString("Apellido"));
            contacto.setCorreo(datos.getString("Correo"));
            contacto.setCiudad(datos.getString("Ciudad"));
            contacto.setUsuario(datos.getString("Usuario"));
            contacto.setContraseña(datos.getString("Contraseña"));
            listaContactos.add(contacto);

        }
        System.out.println(listaContactos);
        conexion.closeConnection();
        return listaContactos;
    }

    public Contacto obtenerContacto(String Nombre) throws SQLException {
        ConexionBD conexion = new ConexionBD();
        String sentencia = "SELECT * FROM contactos WHERE Nombre ='" + Nombre + "'";
        ResultSet datos = conexion.consultarBD(sentencia);
        if (datos.next()) {
            Contacto contacto = new Contacto();
            contacto.setNombre(datos.getString("Nombre"));
            contacto.setApellido(datos.getString("Apellido"));
            contacto.setCorreo(datos.getString("Correo"));
            contacto.setCiudad(datos.getString("Ciudad"));
            contacto.setUsuario(datos.getString("Usuario"));
            contacto.setContraseña(datos.getString("Contraseña"));
            return contacto;

        } else {
            conexion.closeConnection();
            return null;
        }
    }

}
